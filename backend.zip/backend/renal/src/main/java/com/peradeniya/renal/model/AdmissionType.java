package com.peradeniya.renal.model;

public enum AdmissionType {
    DIRECT,
    TRANSFER_FROM_OTHER_WARD,
    HOSPITAL,
    HD,
    OTHER
}
