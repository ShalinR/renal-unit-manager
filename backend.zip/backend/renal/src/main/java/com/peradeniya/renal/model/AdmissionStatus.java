package com.peradeniya.renal.model;

public enum AdmissionStatus {
    ADMITTED,
    DISCHARGED
}
