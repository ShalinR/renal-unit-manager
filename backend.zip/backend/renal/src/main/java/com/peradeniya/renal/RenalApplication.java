package com.peradeniya.renal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RenalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RenalApplication.class, args);
	}

}
